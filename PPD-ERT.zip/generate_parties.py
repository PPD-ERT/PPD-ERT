import party_class
import numpy as np
import random



def generate(global_seed, number_of_parties, train_set, attribute_information,\
             number_target_classes, attributes_range,personal_random_seeds, attribute_percentage, Data_split_train_test_seed=None):
    number_of_training_samples = train_set.shape[0]
    #Shuffle data samples
    np.random.seed(seed=Data_split_train_test_seed)
    indices = np.arange(number_of_training_samples)
    np.random.shuffle(indices)

    data_subsets_indices = np.array_split(indices, number_of_parties)


    parties = []
    for i in range(number_of_parties):
        parties.append(party_class.party(global_seed=global_seed,\
                                         data_subset=train_set[data_subsets_indices[i],:],\
                                         attribute_range=attributes_range,\
                                         attribute_info=attribute_information,\
                                         num_target_classes=number_target_classes,\
                                         personal_random_seed=personal_random_seeds[i],\
                                         attribute_percentage = attribute_percentage))

    print("A list of parties have been created.\n\
    Data samples radomely assigned to each party.\n\
    The proportion of number of samples for each party is almost equal.")
    return parties